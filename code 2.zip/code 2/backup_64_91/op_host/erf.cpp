// Host侧Tiling实现
#include "register/op_def_registry.h"
#include "tiling/platform/platform_ascendc.h"

#include "../op_kernel/erf_tiling.h"
#include "../op_kernel/tiling_key_erf.h"

namespace optiling {
    static ge::graphStatus TilingFunc(gert::TilingContext *context) {
        auto platform = platform_ascendc::PlatformAscendC(context->GetPlatformInfo());
        uint32_t num_cores_aiv = platform.GetCoreNumAiv();

        const gert::Tensor *tensor_x = context->GetRequiredInputTensor(0);
        uint32_t totalLength = tensor_x->GetShapeSize();

        // 按8元素(32字节)为一个block进行分块
        uint32_t ALIGN_NUM = 8;
        uint32_t total_blocks = (totalLength + ALIGN_NUM - 1) / ALIGN_NUM;

        // 核数不超过总block数
        if (total_blocks < num_cores_aiv) {
            num_cores_aiv = total_blocks;
        }
        if (num_cores_aiv == 0) {
            num_cores_aiv = 1;
        }

        // 均匀分配block到各核
        uint32_t tiling_n = total_blocks / num_cores_aiv;
        uint32_t tiling_tail = total_blocks % num_cores_aiv;

        context->SetBlockDim(num_cores_aiv);

        // 填充tiling数据
        ErfTilingData tiling;
        tiling.set_totalLength(totalLength);
        tiling.set_tileNum(1);
        tiling.set_ALIGN_NUM(ALIGN_NUM);
        tiling.set_tiling_n(tiling_n);
        tiling.set_tiling_tail(tiling_tail);

        tiling.SaveToBuffer(context->GetRawTilingData()->GetData(), context->GetRawTilingData()->GetCapacity());
        context->GetRawTilingData()->SetDataSize(tiling.GetDataSize());

        // 配置tiling key用于模板分发
        ge::DataType dtype_x = tensor_x->GetDataType();
        uint32_t DT_X = static_cast<uint32_t>(dtype_x);
        ASCENDC_TPL_SEL_PARAM(context, DT_X);

        // 8MB workspace安全阈值
        size_t *currentWorkspace = context->GetWorkspaceSizes(1);
        currentWorkspace[0] = 8 * 1024 * 1024;
        return ge::GRAPH_SUCCESS;
    }
}  // namespace optiling

namespace ge {
    static graphStatus InferShape(gert::InferShapeContext *context) {
        return GRAPH_SUCCESS;
    }
    static graphStatus InferDataType(gert::InferDataTypeContext *context) {
        return ge::GRAPH_SUCCESS;
    }
}  // namespace ge

namespace ops {
    class Erf : public OpDef {
    public:
        explicit Erf(const char *name) : OpDef(name) {
            this->Input("x")
                .ParamType(REQUIRED)
                .DataType({ge::DT_FLOAT})
                .Format({ge::FORMAT_ND});
            this->Output("y")
                .ParamType(REQUIRED)
                .DataType({ge::DT_FLOAT})
                .Format({ge::FORMAT_ND});
            this->SetInferShape(ge::InferShape).SetInferDataType(ge::InferDataType);
            this->AICore()
                .SetTiling(optiling::TilingFunc)
                .AddConfig("ascend910b");
        }
    };
    OP_ADD(Erf);
}  // namespace ops
