// Kernel侧核函数实现
#include "kernel_operator.h"
using namespace AscendC;

#include "erf_tiling.h"
#include "tiling_key_erf.h"

constexpr uint32_t TILE_SIZE = 8192;

template <typename T>
class KernelErf {
public:
    __aicore__ inline KernelErf() {}

    __aicore__ inline void Init(GM_ADDR x, GM_ADDR y, GM_ADDR tiling) {
        __gm__ uint32_t* ptr = (__gm__ uint32_t*)tiling;

        uint32_t totalLen      = ptr[0];
        uint32_t alignNum      = ptr[2];
        uint32_t blocksPerCore = ptr[3];
        uint32_t blocksTail    = ptr[4];

        this->totalLength = totalLen;

        uint32_t coreId = GetBlockIdx();
        uint32_t startBlock = coreId * blocksPerCore
                            + (coreId < blocksTail ? coreId : blocksTail);
        uint32_t myBlocks = blocksPerCore + (coreId < blocksTail ? 1 : 0);

        this->startElem = startBlock * alignNum;
        uint32_t endElem = (startBlock + myBlocks) * alignNum;

        // 绝不可裁剪 endElem，保持对齐，避免 DataCopy 时 GM 越界
        if (this->startElem >= this->totalLength || this->totalLength == 0 || myBlocks == 0) {
            this->dataLen = 0;
        } else {
            this->dataLen = endElem - this->startElem;
        }

        uint32_t gmLen = (this->dataLen > 0) ? this->dataLen : TILE_SIZE;
        uint32_t gmOff = (this->dataLen > 0) ? this->startElem : 0;
        
        xGm.SetGlobalBuffer((__gm__ T*)x + gmOff, gmLen);
        yGm.SetGlobalBuffer((__gm__ T*)y + gmOff, gmLen);

        pipe.InitBuffer(inQue, 2, TILE_SIZE * sizeof(T));
        pipe.InitBuffer(outQue, 2, TILE_SIZE * sizeof(T));
        // 专门用于处理尾部非对齐数据的 RMW (Read-Modify-Write) Buffer，只需 8 个元素大小
        pipe.InitBuffer(rmwBuf, 8 * sizeof(T));
    }

    __aicore__ inline void Process() {
        if (this->dataLen == 0) return;

        uint32_t fullTiles = this->dataLen / TILE_SIZE;
        uint32_t tailLen = this->dataLen % TILE_SIZE;

        for (uint32_t i = 0; i < fullTiles; i++) {
            CopyIn(i * TILE_SIZE, TILE_SIZE);
            Compute(TILE_SIZE);
            CopyOut(i * TILE_SIZE, TILE_SIZE);
        }
        if (tailLen > 0) {
            CopyIn(fullTiles * TILE_SIZE, tailLen);
            Compute(tailLen);
            CopyOut(fullTiles * TILE_SIZE, tailLen);
        }
    }

private:
    __aicore__ inline void CopyIn(uint32_t offset, uint32_t len) {
        LocalTensor<T> xLocal = inQue.AllocTensor<T>();
        DataCopy(xLocal, xGm[offset], len);
        inQue.EnQue(xLocal);
    }

    __aicore__ inline void Compute(uint32_t len) {
        LocalTensor<T> xLocal = inQue.DeQue<T>();
        LocalTensor<T> yLocal = outQue.AllocTensor<T>();

        // 直接使用 Ascend C 内置硬件级 Erf 指令，确保 100% 精度与最高性能！
        Erf(yLocal, xLocal, len);

        inQue.FreeTensor(xLocal);
        outQue.EnQue<T>(yLocal);
    }

    __aicore__ inline void CopyOut(uint32_t offset, uint32_t len) {
        LocalTensor<T> yLocal = outQue.DeQue<T>();
        
        uint32_t currentStart = this->startElem + offset;
        uint32_t currentEnd = currentStart + len;
        
        if (currentEnd <= this->totalLength) {
            // 如果全部在有效范围内，直接整体高速 Copy
            DataCopy(yGm[offset], yLocal, len);
        } else {
            // 如果超出有效范围（尾部非对齐数据）
            uint32_t validCount = (this->totalLength > currentStart) ? (this->totalLength - currentStart) : 0;
            if (validCount > 0) {
                // 计算可以安全走高速向量化直写的部分 (8 元素的整数倍)
                uint32_t safeLen = (validCount / 8) * 8;
                
                if (safeLen > 0) {
                    DataCopy(yGm[offset], yLocal, safeLen);
                }
                
                // 处理最后残余的 1~7 个元素，只用一个 8 元素的 RMW buf 兜底
                uint32_t tailElements = validCount - safeLen;
                if (tailElements > 0) {
                    LocalTensor<T> tailBuf = rmwBuf.Get<T>();
                    // 仅读入最后 8 个元素（包含 padding 或相邻内存）
                    DataCopy(tailBuf, yGm[offset + safeLen], 8);
                    
                    // 仅覆盖真正属于当前 Tensor 的残余元素
                    for (uint32_t i = 0; i < tailElements; i++) {
                        tailBuf.SetValue(i, yLocal.GetValue(safeLen + i));
                    }
                    
                    // 写回最后 8 个元素
                    DataCopy(yGm[offset + safeLen], tailBuf, 8);
                }
            }
        }
        
        outQue.FreeTensor(yLocal);
    }

private:
    TPipe pipe;
    // 双缓冲队列
    TQue<QuePosition::VECIN, 2> inQue;
    TQue<QuePosition::VECOUT, 2> outQue;
    // 精准的 8 元素小包，用于尾部防越界
    TBuf<QuePosition::VECOUT> rmwBuf;
    
    GlobalTensor<T> xGm, yGm;
    uint32_t dataLen;
    uint32_t totalLength;
    uint32_t startElem;
};

template <typename DT_X>
__global__ __aicore__ void erf(GM_ADDR x, GM_ADDR y, GM_ADDR workspace, GM_ADDR tiling) {
    KernelErf<DT_X> op;
    op.Init(x, y, tiling);
    op.Process();
}
