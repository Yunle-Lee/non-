// Kernel侧核函数实现
#include "kernel_operator.h"
using namespace AscendC;

#include "erf_tiling.h"
#include "tiling_key_erf.h"

constexpr uint32_t TILE_SIZE = 8192;

template <typename T>
class KernelErf {
public:
    __aicore__ inline KernelErf() {}

    __aicore__ inline void Init(GM_ADDR x, GM_ADDR y, uint32_t totalLen, uint32_t alignNum, uint32_t blocksPerCore, uint32_t blocksTail) {

        this->totalLength = totalLen;

        uint32_t coreId = GetBlockIdx();
        uint32_t startBlock = coreId * blocksPerCore
                            + (coreId < blocksTail ? coreId : blocksTail);
        uint32_t myBlocks = blocksPerCore + (coreId < blocksTail ? 1 : 0);

        this->startElem = startBlock * alignNum;
        uint32_t endElem = (startBlock + myBlocks) * alignNum;

        if (this->startElem >= this->totalLength || this->totalLength == 0 || myBlocks == 0) {
            this->dataLen = 0;
        } else {
            this->dataLen = endElem - this->startElem;
        }

        uint32_t gmLen = (this->dataLen > 0) ? this->dataLen : TILE_SIZE;
        uint32_t gmOff = (this->dataLen > 0) ? this->startElem : 0;
        
        xGm.SetGlobalBuffer((__gm__ T*)x + gmOff, gmLen);
        yGm.SetGlobalBuffer((__gm__ T*)y + gmOff, gmLen);

        pipe.InitBuffer(inQue, 2, TILE_SIZE * sizeof(T));
        pipe.InitBuffer(outQue, 2, TILE_SIZE * sizeof(T));
        pipe.InitBuffer(calcBuf, 2, TILE_SIZE * sizeof(T));
    }

    __aicore__ inline void Process() {
        if (this->dataLen == 0) return;

        uint32_t fullTiles = this->dataLen / TILE_SIZE;
        uint32_t tailLen = this->dataLen % TILE_SIZE;

        for (uint32_t i = 0; i < fullTiles; i++) {
            CopyIn(i * TILE_SIZE, TILE_SIZE);
            Compute(TILE_SIZE);
            CopyOut(i * TILE_SIZE, TILE_SIZE);
        }
        if (tailLen > 0) {
            CopyIn(fullTiles * TILE_SIZE, tailLen);
            Compute(tailLen);
            CopyOut(fullTiles * TILE_SIZE, tailLen);
        }
    }

private:
    __aicore__ inline void CopyIn(uint32_t offset, uint32_t len) {
        LocalTensor<T> xLocal = inQue.AllocTensor<T>();
        
        uint32_t currentStart = this->startElem + offset;
        uint32_t validCount = (this->totalLength > currentStart) ? (this->totalLength - currentStart) : 0;
        
        if (validCount >= len) {
            DataCopy(xLocal, xGm[offset], len);
        } else if (validCount > 0) {
            uint32_t safeLen = (validCount / 8) * 8;
            if (safeLen > 0) {
                DataCopy(xLocal, xGm[offset], safeLen);
            }
            uint32_t tailElements = validCount - safeLen;
            for (uint32_t i = 0; i < tailElements; i++) {
                xLocal.SetValue(safeLen + i, xGm.GetValue(offset + safeLen + i));
            }
            // 填充剩余的对齐数据为0，防止未初始化内存产生 NaN 污染向量计算
            for (uint32_t i = validCount; i < len; i++) {
                xLocal.SetValue(i, (T)0.0f);
            }
        } else {
            for (uint32_t i = 0; i < len; i++) {
                xLocal.SetValue(i, (T)0.0f);
            }
        }
        
        inQue.EnQue(xLocal);
    }

    __aicore__ inline void Compute(uint32_t len) {
        LocalTensor<T> xLocal = inQue.DeQue<T>();
        LocalTensor<T> yLocal = outQue.AllocTensor<T>();

        LocalTensor<T> pVal = calcBuf.AllocTensor<T>();
        LocalTensor<T> qVal = calcBuf.AllocTensor<T>();

        // 1. 裁剪 x 保证大值收敛 (3.92 已足够)
        Mins(xLocal, xLocal, (T)3.92f, len);
        Maxs(xLocal, xLocal, (T)(-3.92f), len);

        // 2. 直接计算 t = x^2 到 qVal，省去一条额外的 Adds 拷贝指令
        Mul(qVal, xLocal, xLocal, len); 

        // 3. 计算多项式 P(t) - 三阶极速极限版 (误差 4.75e-5，减少25%指令)
        Muls(pVal, qVal, (T)0.0765003369f, len);
        Adds(pVal, pVal, (T)4.8976118069f, len);
        Mul(pVal, pVal, qVal, len);
        Adds(pVal, pVal, (T)19.3799329272f, len);
        Mul(pVal, pVal, qVal, len);
        Adds(pVal, pVal, (T)132.7787037064f, len);
        
        Mul(pVal, pVal, xLocal, len); // P(t) * x

        // 4. 计算多项式 Q(t) 到 yLocal (三阶，复用 yLocal 从而无需额外申请)
        Adds(yLocal, qVal, (T)11.4206247941f, len);
        Mul(yLocal, yLocal, qVal, len);
        Adds(yLocal, yLocal, (T)56.3652103771f, len);
        Mul(yLocal, yLocal, qVal, len);
        Adds(yLocal, yLocal, (T)117.6776544494f, len);

        // 5. 最终组合 y = P(t)*x / Q(t)
        Div(yLocal, pVal, yLocal, len);

        calcBuf.FreeTensor(qVal);
        calcBuf.FreeTensor(pVal);

        inQue.FreeTensor(xLocal);
        outQue.EnQue<T>(yLocal);
    }

    __aicore__ inline void CopyOut(uint32_t offset, uint32_t len) {
        LocalTensor<T> yLocal = outQue.DeQue<T>();
        
        uint32_t currentStart = this->startElem + offset;
        uint32_t currentEnd = currentStart + len;
        
        if (currentEnd <= this->totalLength) {
            DataCopy(yGm[offset], yLocal, len);
        } else {
            uint32_t validCount = (this->totalLength > currentStart) ? (this->totalLength - currentStart) : 0;
            if (validCount > 0) {
                uint32_t safeLen = (validCount / 8) * 8;
                if (safeLen > 0) {
                    DataCopy(yGm[offset], yLocal, safeLen);
                }
                
                uint32_t tailElements = validCount - safeLen;
                for (uint32_t i = 0; i < tailElements; i++) {
                    yGm.SetValue(offset + safeLen + i, yLocal.GetValue(safeLen + i));
                }
            }
        }
        
        outQue.FreeTensor(yLocal);
    }

private:
    TPipe pipe;
    TQue<QuePosition::VECIN, 2> inQue;
    TQue<QuePosition::VECOUT, 2> outQue;
    TQue<QuePosition::VECCALC, 2> calcBuf;
    
    GlobalTensor<T> xGm, yGm;
    uint32_t dataLen;
    uint32_t totalLength;
    uint32_t startElem;
};

template <typename DT_X>
__global__ __aicore__ void erf(GM_ADDR x, GM_ADDR y, GM_ADDR workspace, GM_ADDR tiling) {
    GET_TILING_DATA(tiling_data, tiling);
    KernelErf<DT_X> op;
    op.Init(x, y, tiling_data.totalLength, tiling_data.ALIGN_NUM, tiling_data.tiling_n, tiling_data.tiling_tail);
    op.Process();
}
