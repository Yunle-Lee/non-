// Kernel侧核函数实现
#include "kernel_operator.h"
using namespace AscendC;

#include "erf_tiling.h"
#include "tiling_key_erf.h"

constexpr uint32_t TILE_SIZE = 8192;

template <typename T>
class KernelErf {
public:
    __aicore__ inline KernelErf() {}

    __aicore__ inline void Init(GM_ADDR x, GM_ADDR y, uint32_t totalLen, uint32_t alignNum, uint32_t blocksPerCore, uint32_t blocksTail) {
        this->totalLength = totalLen;

        uint32_t coreId = GetBlockIdx();
        uint32_t startBlock = coreId * blocksPerCore + (coreId < blocksTail ? coreId : blocksTail);
        uint32_t myBlocks = blocksPerCore + (coreId < blocksTail ? 1 : 0);

        this->startElem = startBlock * alignNum;
        uint32_t endElem = (startBlock + myBlocks) * alignNum;
        
        // 核心优化：在 Init 阶段绝对截断越界数据，保证后续 pipeline 中处理的长度 100% 有效！
        if (endElem > this->totalLength) {
            endElem = this->totalLength;
        }

        if (this->startElem >= this->totalLength || myBlocks == 0) {
            this->dataLen = 0;
        } else {
            this->dataLen = endElem - this->startElem;
        }

        uint32_t gmOff = (this->dataLen > 0) ? this->startElem : 0;
        uint32_t actualLen = this->dataLen; // 已截断，绝对安全
        uint32_t gmLen = (actualLen + 7) / 8 * 8;
        if (gmLen == 0) gmLen = 8;
        
        xGm.SetGlobalBuffer((__gm__ T*)x + gmOff, gmLen);
        yGm.SetGlobalBuffer((__gm__ T*)y + gmOff, gmLen);

        pipe.InitBuffer(inQue, 2, TILE_SIZE * sizeof(T));
        pipe.InitBuffer(outQue, 2, TILE_SIZE * sizeof(T));
        pipe.InitBuffer(pBuf, TILE_SIZE * sizeof(T));
        pipe.InitBuffer(qBuf, TILE_SIZE * sizeof(T));
    }

    __aicore__ inline void Process() {
        if (this->dataLen == 0) return;

        // 【终极必杀】单 Tile 直通车：绕过 TQue 昂贵的硬件队列握手惩罚！
        if (this->dataLen <= TILE_SIZE) {
            uint32_t len = this->dataLen;
            LocalTensor<T> xLocal = inQue.AllocTensor<T>();
            LocalTensor<T> yLocal = outQue.AllocTensor<T>();
            LocalTensor<T> pVal = pBuf.Get<T>();
            LocalTensor<T> qVal = qBuf.Get<T>();

            // 1. 直通搬入
            uint32_t safeLen = (len / 8) * 8;
            if (safeLen > 0) {
                DataCopy(xLocal, xGm[0], safeLen);
            }
            uint32_t tail = len - safeLen;
            if (tail > 0) {
                DataCopy(xLocal[safeLen], xGm[safeLen], 8);
            }

            // 极速屏障：等待 MTE2 搬运完毕
            pipe_barrier(PIPE_ALL);

            // 2. 直通计算：0 FPE 风险，真实长度运算
            Mins(xLocal, xLocal, (T)3.92f, len);
            Maxs(xLocal, xLocal, (T)(-3.92f), len);

            Mul(qVal, xLocal, xLocal, len); 

            Muls(pVal, qVal, (T)0.0765003369f, len);
            Adds(pVal, pVal, (T)4.8976118069f, len);
            Mul(pVal, pVal, qVal, len);
            Adds(pVal, pVal, (T)19.3799329272f, len);
            Mul(pVal, pVal, qVal, len);
            Adds(pVal, pVal, (T)132.7787037064f, len);
            
            Mul(pVal, pVal, xLocal, len); 

            Adds(yLocal, qVal, (T)11.4206247941f, len);
            Mul(yLocal, yLocal, qVal, len);
            Adds(yLocal, yLocal, (T)56.3652103771f, len);
            Mul(yLocal, yLocal, qVal, len);
            Adds(yLocal, yLocal, (T)117.6776544494f, len);

            Div(yLocal, pVal, yLocal, len);

            // 极速屏障：等待 Vector 计算完毕
            pipe_barrier(PIPE_ALL);

            // 3. 直通搬出
            if (safeLen > 0) {
                DataCopy(yGm[0], yLocal, safeLen);
            }
            if (tail > 0) {
                DataCopy(yGm[safeLen], yLocal[safeLen], 8);
            }

            // 极速屏障：等待 MTE3 搬运完毕
            pipe_barrier(PIPE_ALL);
            
            inQue.FreeTensor(xLocal);
            outQue.FreeTensor(yLocal);
            return;
        }

        // 多 Tile 大数据管线车：启用 TQue 完美隐藏搬运延时
        uint32_t fullTiles = this->dataLen / TILE_SIZE;
        uint32_t tailLen = this->dataLen % TILE_SIZE;

        for (uint32_t i = 0; i < fullTiles; i++) {
            CopyIn(i * TILE_SIZE, TILE_SIZE);
            Compute(TILE_SIZE);
            CopyOut(i * TILE_SIZE, TILE_SIZE);
        }
        if (tailLen > 0) {
            CopyIn(fullTiles * TILE_SIZE, tailLen);
            Compute(tailLen);
            CopyOut(fullTiles * TILE_SIZE, tailLen);
        }
    }

private:
    __aicore__ inline void CopyIn(uint32_t offset, uint32_t len) {
        LocalTensor<T> xLocal = inQue.AllocTensor<T>();
        
        // 去除所有边界推断标量计算，直接使用绝对真实的物理长度搬运
        uint32_t safeLen = (len / 8) * 8;
        if (safeLen > 0) {
            DataCopy(xLocal, xGm[offset], safeLen);
        }
        
        uint32_t tailElements = len - safeLen;
        if (tailElements > 0) {
            DataCopy(xLocal[safeLen], xGm[offset + safeLen], 8);
        }
        
        inQue.EnQue(xLocal);
    }

    __aicore__ inline void Compute(uint32_t len) {
        LocalTensor<T> xLocal = inQue.DeQue<T>();
        LocalTensor<T> yLocal = outQue.AllocTensor<T>();

        LocalTensor<T> pVal = pBuf.Get<T>();
        LocalTensor<T> qVal = qBuf.Get<T>();

        // 全局传入有效真实长度，既保证最高级展开优化，又物理绝缘 FPE 异常
        Mins(xLocal, xLocal, (T)3.92f, len);
        Maxs(xLocal, xLocal, (T)(-3.92f), len);

        Mul(qVal, xLocal, xLocal, len); 

        Muls(pVal, qVal, (T)0.0765003369f, len);
        Adds(pVal, pVal, (T)4.8976118069f, len);
        Mul(pVal, pVal, qVal, len);
        Adds(pVal, pVal, (T)19.3799329272f, len);
        Mul(pVal, pVal, qVal, len);
        Adds(pVal, pVal, (T)132.7787037064f, len);
        
        Mul(pVal, pVal, xLocal, len); 

        Adds(yLocal, qVal, (T)11.4206247941f, len);
        Mul(yLocal, yLocal, qVal, len);
        Adds(yLocal, yLocal, (T)56.3652103771f, len);
        Mul(yLocal, yLocal, qVal, len);
        Adds(yLocal, yLocal, (T)117.6776544494f, len);

        Div(yLocal, pVal, yLocal, len);

        inQue.FreeTensor(xLocal);
        outQue.EnQue<T>(yLocal);
    }

    __aicore__ inline void CopyOut(uint32_t offset, uint32_t len) {
        LocalTensor<T> yLocal = outQue.DeQue<T>();
        
        uint32_t safeLen = (len / 8) * 8;
        if (safeLen > 0) {
            DataCopy(yGm[offset], yLocal, safeLen);
        }
        
        uint32_t tailElements = len - safeLen;
        if (tailElements > 0) {
            DataCopy(yGm[offset + safeLen], yLocal[safeLen], 8);
        }
        
        outQue.FreeTensor(yLocal);
    }

private:
    TPipe pipe;
    TQue<QuePosition::VECIN, 2> inQue;
    TQue<QuePosition::VECOUT, 2> outQue;
    
    TBuf<QuePosition::VECCALC> pBuf; // 轻量级计算缓存1
    TBuf<QuePosition::VECCALC> qBuf; // 轻量级计算缓存2
    TBuf<QuePosition::VECOUT> rmwBuf; // RMW 尾部安全搬运极速缓冲区
    
    GlobalTensor<T> xGm, yGm;
    uint32_t dataLen;
    uint32_t totalLength;
    uint32_t startElem;
};

template <typename DT_X>
__global__ __aicore__ void erf(GM_ADDR x, GM_ADDR y, GM_ADDR workspace, GM_ADDR tiling) {
    GET_TILING_DATA(tiling_data, tiling);
    KernelErf<DT_X> op;
    op.Init(x, y, tiling_data.totalLength, tiling_data.ALIGN_NUM, tiling_data.tiling_n, tiling_data.tiling_tail);
    op.Process();
}
