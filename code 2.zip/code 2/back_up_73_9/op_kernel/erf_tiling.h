// Tiling结构体定义的头文件
#ifndef ERF_TILING_H
#define ERF_TILING_H

#ifndef __aicore__
#include "register/tilingdata_base.h"

namespace optiling {
BEGIN_TILING_DATA_DEF(ErfTilingData)
    TILING_DATA_FIELD_DEF(uint32_t, totalLength);
    TILING_DATA_FIELD_DEF(uint32_t, tileNum);
    TILING_DATA_FIELD_DEF(uint32_t, ALIGN_NUM);
    TILING_DATA_FIELD_DEF(uint32_t, tiling_n);
    TILING_DATA_FIELD_DEF(uint32_t, tiling_tail);
END_TILING_DATA_DEF;

REGISTER_TILING_DATA_CLASS(Erf, ErfTilingData)
}
#endif // __aicore__
#endif
