// Kernel侧核函数实现
#include "kernel_operator.h"
using namespace AscendC;

#include "erf_tiling.h"
#include "tiling_key_erf.h"

constexpr uint32_t TILE_SIZE = 8192;

template <typename T>
class KernelErf {
public:
    __aicore__ inline KernelErf() {}

    __aicore__ inline void Init(GM_ADDR x, GM_ADDR y, uint32_t totalLen, uint32_t alignNum, uint32_t blocksPerCore, uint32_t blocksTail) {
        this->totalLength = totalLen;

        uint32_t coreId = GetBlockIdx();
        uint32_t startBlock = coreId * blocksPerCore + (coreId < blocksTail ? coreId : blocksTail);
        uint32_t myBlocks = blocksPerCore + (coreId < blocksTail ? 1 : 0);

        this->startElem = startBlock * alignNum;
        uint32_t endElem = (startBlock + myBlocks) * alignNum;
        
        if (endElem > this->totalLength) {
            endElem = this->totalLength;
        }

        if (this->startElem >= this->totalLength || myBlocks == 0) {
            this->dataLen = 0;
        } else {
            this->dataLen = endElem - this->startElem;
        }

        uint32_t gmOff = (this->dataLen > 0) ? this->startElem : 0;
        uint32_t gmLen = (this->dataLen + 7) / 8 * 8;
        if (gmLen == 0) gmLen = 8;
        
        xGm.SetGlobalBuffer((__gm__ T*)x + gmOff, gmLen);
        yGm.SetGlobalBuffer((__gm__ T*)y + gmOff, gmLen);

        if (this->dataLen <= TILE_SIZE) {
            uint32_t bufSize = (this->dataLen + 7) / 8 * 8;
            if (bufSize < 8) bufSize = 8;
            pipe.InitBuffer(xBuf, bufSize * sizeof(T));
            pipe.InitBuffer(yBuf, bufSize * sizeof(T));
            pipe.InitBuffer(pBuf, bufSize * sizeof(T));
            pipe.InitBuffer(qBuf, bufSize * sizeof(T));
        } else {
            pipe.InitBuffer(inQue, 2, TILE_SIZE * sizeof(T));
            pipe.InitBuffer(outQue, 2, TILE_SIZE * sizeof(T));
            pipe.InitBuffer(pBuf, TILE_SIZE * sizeof(T));
            pipe.InitBuffer(qBuf, TILE_SIZE * sizeof(T));
        }
    }

    __aicore__ inline void Process() {
        if (this->dataLen == 0) return;

        if (this->dataLen <= TILE_SIZE) {
            uint32_t len = this->dataLen;
            uint32_t alignLen = (len + 7) / 8 * 8;
            
            LocalTensor<T> xLocal = xBuf.Get<T>();
            LocalTensor<T> yLocal = yBuf.Get<T>();
            LocalTensor<T> pVal = pBuf.Get<T>();
            LocalTensor<T> qVal = qBuf.Get<T>();

            DataCopy(xLocal, xGm[0], alignLen);
            SetFlag<HardEvent::MTE2_V>(0);
            WaitFlag<HardEvent::MTE2_V>(0);

            Mins(xLocal, xLocal, (T)3.92f, len);
            Maxs(xLocal, xLocal, (T)(-3.92f), len);
            Mul(qVal, xLocal, xLocal, len); 
            Muls(pVal, qVal, (T)0.0765003369f, len);
            Adds(pVal, pVal, (T)4.8976118069f, len);
            Mul(pVal, pVal, qVal, len);
            Adds(pVal, pVal, (T)19.3799329272f, len);
            Mul(pVal, pVal, qVal, len);
            Adds(pVal, pVal, (T)132.7787037064f, len);
            Mul(pVal, pVal, xLocal, len); 
            Adds(yLocal, qVal, (T)11.4206247941f, len);
            Mul(yLocal, yLocal, qVal, len);
            Adds(yLocal, yLocal, (T)56.3652103771f, len);
            Mul(yLocal, yLocal, qVal, len);
            Adds(yLocal, yLocal, (T)117.6776544494f, len);
            Div(yLocal, pVal, yLocal, len);

            SetFlag<HardEvent::V_MTE3>(0);
            WaitFlag<HardEvent::V_MTE3>(0);

            DataCopy(yGm[0], yLocal, alignLen);
            SetFlag<HardEvent::MTE3_V>(0);
            WaitFlag<HardEvent::MTE3_V>(0);
            return;
        }

        uint32_t fullTiles = this->dataLen / TILE_SIZE;
        uint32_t tailLen = this->dataLen % TILE_SIZE;

        for (uint32_t i = 0; i < fullTiles; i++) {
            CopyIn(i * TILE_SIZE, TILE_SIZE);
            Compute(TILE_SIZE);
            CopyOut(i * TILE_SIZE, TILE_SIZE);
        }
        if (tailLen > 0) {
            CopyIn(fullTiles * TILE_SIZE, tailLen);
            Compute(tailLen);
            CopyOut(fullTiles * TILE_SIZE, tailLen);
        }
    }

private:
    __aicore__ inline void CopyIn(uint32_t offset, uint32_t len) {
        LocalTensor<T> xLocal = inQue.AllocTensor<T>();
        uint32_t alignLen = (len + 7) / 8 * 8;
        DataCopy(xLocal, xGm[offset], alignLen);
        inQue.EnQue(xLocal);
    }

    __aicore__ inline void Compute(uint32_t len) {
        LocalTensor<T> xLocal = inQue.DeQue<T>();
        LocalTensor<T> yLocal = outQue.AllocTensor<T>();
        LocalTensor<T> pVal = pBuf.Get<T>();
        LocalTensor<T> qVal = qBuf.Get<T>();

        uint32_t alignLen = (len + 7) / 8 * 8;

        Mins(xLocal, xLocal, (T)3.92f, len);
        Maxs(xLocal, xLocal, (T)(-3.92f), len);

        Mul(qVal, xLocal, xLocal, len); 

        Muls(pVal, qVal, (T)0.0765003369f, len);
        Adds(pVal, pVal, (T)4.8976118069f, len);
        Mul(pVal, pVal, qVal, len);
        Adds(pVal, pVal, (T)19.3799329272f, len);
        Mul(pVal, pVal, qVal, len);
        Adds(pVal, pVal, (T)132.7787037064f, len);
        
        Mul(pVal, pVal, xLocal, len); 

        Adds(yLocal, qVal, (T)11.4206247941f, len);
        Mul(yLocal, yLocal, qVal, len);
        Adds(yLocal, yLocal, (T)56.3652103771f, len);
        Mul(yLocal, yLocal, qVal, len);
        Adds(yLocal, yLocal, (T)117.6776544494f, len);

        Div(yLocal, pVal, yLocal, len);

        inQue.FreeTensor(xLocal);
        outQue.EnQue<T>(yLocal);
    }

    __aicore__ inline void CopyOut(uint32_t offset, uint32_t len) {
        LocalTensor<T> yLocal = outQue.DeQue<T>();
        uint32_t alignLen = (len + 7) / 8 * 8;
        DataCopy(yGm[offset], yLocal, alignLen);
        outQue.FreeTensor(yLocal);
    }

private:
    TPipe pipe;
    TQue<QuePosition::VECIN, 2> inQue;
    TQue<QuePosition::VECOUT, 2> outQue;
    TBuf<QuePosition::VECIN> xBuf;
    TBuf<QuePosition::VECOUT> yBuf;
    
    TBuf<QuePosition::VECCALC> pBuf;
    TBuf<QuePosition::VECCALC> qBuf;
    
    GlobalTensor<T> xGm, yGm;
    uint32_t dataLen;
    uint32_t totalLength;
    uint32_t startElem;
};

template <typename DT_X>
__global__ __aicore__ void erf(GM_ADDR x, GM_ADDR y, GM_ADDR workspace, GM_ADDR tiling) {
    GET_TILING_DATA(tiling_data, tiling);
    KernelErf<DT_X> op;
    op.Init(x, y, tiling_data.totalLength, tiling_data.ALIGN_NUM, tiling_data.tiling_n, tiling_data.tiling_tail);
    op.Process();
}
